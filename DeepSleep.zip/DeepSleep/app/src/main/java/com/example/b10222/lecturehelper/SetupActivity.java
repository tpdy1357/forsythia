package com.example.b10222.lecturehelper;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import java.util.Calendar;

public class SetupActivity extends AppCompatActivity {

    Button alarmsetup;
    Button bluetooth;
    Button etc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setup);

        alarmsetup = (Button) findViewById(R.id.alarmsetup);
        bluetooth = (Button) findViewById(R.id.bluetooth);
        etc = (Button) findViewById(R.id.etc);

        alarmsetup.setOnClickListener(mClickListener);
        bluetooth.setOnClickListener(mClickListener);
        etc.setOnClickListener(mClickListener);

        time_background();
    }

    Button.OnClickListener mClickListener = new View.OnClickListener() {
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.alarmsetup:
                    Intent intent1 = new Intent(SetupActivity.this, AlarmSetupActivity.class);
                    startActivity(intent1);
                    break;
                case R.id.bluetooth:
                    Intent intent2 = new Intent(SetupActivity.this, BluetoothActivity.class);
                    startActivity(intent2);
                    break;
                case R.id.etc:
                    Intent intent3 = new Intent(SetupActivity.this, MainActivity.class);
                    startActivity(intent3);
                    break;
            }
        }
    };

    public void time_background(){
        int hour =0;
        final LinearLayout mylayout = (LinearLayout)findViewById(R.id.mainlayout);
        Calendar time = Calendar.getInstance();
        hour = time.get(Calendar.HOUR_OF_DAY);
        if(hour>6 && hour<18){
            mylayout.setBackgroundResource(R.drawable.background2);
        }
        else{
            mylayout.setBackgroundResource(R.drawable.background);
        }
    }//시간에 따라 배경화면 낮, 밤 바꾸기 함수
}
