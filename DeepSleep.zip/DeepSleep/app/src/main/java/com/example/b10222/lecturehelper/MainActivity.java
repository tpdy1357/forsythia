package com.example.b10222.lecturehelper;


import android.content.Context;
import android.content.Intent;
import android.media.AudioFormat;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;


import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    Button sleep;
    Button feedback;
    Button setup;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sleep = (Button) findViewById(R.id.sleep);
        feedback = (Button) findViewById(R.id.feedback);
        setup = (Button) findViewById(R.id.setup);

        sleep.setOnClickListener(mClickListener);
        feedback.setOnClickListener(mClickListener);
        setup.setOnClickListener(mClickListener);

        time_background();

    }

    Button.OnClickListener mClickListener = new View.OnClickListener() {
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.sleep:
                   // Intent intent1 = new Intent(MainActivity.this, SleepStartActivity.class);
                   // startActivity(intent1);
                    Vibrator mVibe = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    mVibe.vibrate(1000);
                    break;
                case R.id.feedback:
                    Intent intent2 = new Intent(MainActivity.this, FeedbackActivity.class);
                    startActivity(intent2);
                    break;
                case R.id.setup:
                    Intent intent3 = new Intent(MainActivity.this, SetupActivity.class);
                    startActivity(intent3);
                    break;
            }
        }
    };//메인화면의 버튼이 클릭되었을 때 각각의 반응

    public void time_background(){
        int hour =0;
        final LinearLayout mylayout = (LinearLayout)findViewById(R.id.mainlayout);
        Calendar time = Calendar.getInstance();
        hour = time.get(Calendar.HOUR_OF_DAY);
        if(hour>6 && hour<18){
            mylayout.setBackgroundResource(R.drawable.background2);
        }
        else{
            mylayout.setBackgroundResource(R.drawable.background);
        }
    }//시간에 따라 배경화면 낮, 밤 바꾸기 함수

}



