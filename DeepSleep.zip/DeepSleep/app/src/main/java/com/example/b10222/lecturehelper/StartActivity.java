package com.example.b10222.lecturehelper;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.content.Intent;
import android.widget.RelativeLayout;

import java.util.Calendar;

public class StartActivity extends AppCompatActivity {

    int value = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
        mHandler.sendEmptyMessage(0);

        time_background();

    }

    Handler mHandler = new Handler(){
        public void handleMessage(Message msg){
            value++;
            if(value == 3){
                Intent intent = new Intent(StartActivity.this, MainActivity.class);
                startActivity(intent);
                StartActivity.this.finish();
            }
            mHandler.sendEmptyMessageDelayed(0,1000);
        }
    };


    public void time_background(){
        int hour = 0;
        final RelativeLayout startlayout = (RelativeLayout)findViewById(R.id.startlayout);
        Calendar time = Calendar.getInstance();
        hour = time.get(Calendar.HOUR_OF_DAY);
        if(hour>6 && hour<18){
            startlayout.setBackgroundResource(R.drawable.background2);
        }
        else{
            startlayout.setBackgroundResource(R.drawable.background);
        }
    }//시간에 따라 배경화면 낮, 밤 바꾸기 함수
}

